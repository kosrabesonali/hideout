<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$lang['upload_button'] = 'Envio de arquivos aqui';
$lang['upload-drop-area'] = 'Arraste e solte os arquivos aqui para enviar';
$lang['upload-cancel'] = 'Cancelado';
$lang['upload-failed'] = 'Falha';

$lang['loading'] = 'Carregando, por favor aguarde ...';
$lang['deleting'] = 'Excluindo, por favor aguarde ...';
$lang['saving_title'] = 'Salvando título ...';

$lang['list_delete'] = 'Excluir';
$lang['alert_delete'] = 'Tem certeza de que deseja apagar esta imagem?';

/* End of file pt-br.php */
/* Location: ./assets/image_crud/languages/pt-br.php */
