<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$lang['upload_button'] = 'Incarcare fişier';
$lang['upload-drop-area'] = 'Fixați fișierele aici pentru a încărca';
$lang['upload-cancel'] = 'Anuleaza';
$lang['upload-failed'] = 'Ne reușit';

$lang['loading'] = 'Încărcare, vă rog, aşteptaţi...';
$lang['deleting'] = 'Ştergere, vă rog, aşteptaţi...';
$lang['saving_title'] = 'Salvare denumire...';

$lang['list_delete'] = 'Ştergeţi';
$lang['alert_delete'] = 'Sunteţi sigur că doriţi să ştergeţi această imagine?';

/* End of file romanian.php */
/* Location: ./assets/image_crud/languages/romanian.php */
