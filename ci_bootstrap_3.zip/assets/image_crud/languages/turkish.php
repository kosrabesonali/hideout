<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$lang['upload_button'] = 'Yüklemek için tıklayın';
$lang['upload-drop-area'] = 'Görselleri buraya sürükleyerek yükleyebilirsiniz';
$lang['upload-cancel'] = 'Kapat';
$lang['upload-failed'] = 'Hata';

$lang['loading'] = 'Yükleniyor, lütfen bekleyiniz...';
$lang['deleting'] = 'Siliniyor, lütfen bekleyiniz...';
$lang['saving_title'] = 'Başlık kaydediliyor...';

$lang['list_delete'] = 'Sil';
$lang['alert_delete'] = 'Bu görseli silmek istediğinize emin misiniz?';

/* End of file turkish.php */
/* Location: ./assets/image_crud/languages/turkish.php */
