<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$lang['upload_button'] = 'Загрузить файлы';
$lang['upload-drop-area'] = 'Перетащите сюда файлы, чтобы загрузить их';
$lang['upload-cancel'] = 'Отмена';
$lang['upload-failed'] = 'Не удалось загрузить';

$lang['loading'] = 'Загрузка, подождите, пожалуйста...';
$lang['deleting'] = 'Удаление, подождите, пожалуйста...';
$lang['saving_title'] = 'Сохранение описания...';

$lang['list_delete'] = 'Удалить';
$lang['alert_delete'] = 'Вы уверены, что хотите удалить это изображение?';

/* End of file russian.php */
/* Location: ./assets/image_crud/languages/russian.php */