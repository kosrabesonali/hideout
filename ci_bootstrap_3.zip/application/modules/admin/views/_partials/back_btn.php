<?php if ( !empty($back_url) ): ?>
	<hr/>
	<a href="<?php echo $back_url; ?>" class="btn bg-purple btn-flat">Back</a>
<?php endif; ?>