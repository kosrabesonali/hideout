<?php $this->load->view('_partials/navbar'); ?>

<?php $this->load->view($inner_view); ?>

<?php $this->load->view('_partials/footer'); ?>