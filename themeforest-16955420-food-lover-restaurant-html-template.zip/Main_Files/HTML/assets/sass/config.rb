http_path = "/"
css_dir = "../css"
sass_dir = "."
images_dir = "../img"
javascripts_dir = "../js"
relative_assets	= true
line_comments = false
output_style = :expanded